import { createClient } from "@supabase/supabase-js"

// Using the provided credentials
const supabaseUrl = "https://hzxgpvooxqlfqipcissz.supabase.co"
const supabaseAnonKey =
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imh6eGdwdm9veHFsZnFpcGNpc3N6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDQ4NjY1NjMsImV4cCI6MjA2MDQ0MjU2M30.creGa4dj985Hor3wPIkd3pQsd243Lrp8E8Q_HUFkWyA"

export const supabase = createClient(supabaseUrl, supabaseAnonKey)
