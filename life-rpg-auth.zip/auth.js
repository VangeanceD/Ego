import { createClient } from "@supabase/supabase-js"

const supabaseUrl = process.env.SUPABASE_URL
const supabaseKey = process.env.SUPABASE_ANON_KEY
const supabase = createClient(supabaseUrl, supabaseKey)

// Check if user is authenticated
async function checkAuth() {
  const {
    data: { session },
  } = await supabase.auth.getSession()

  if (!session) {
    // Redirect to login page if not authenticated
    window.location.href = "login.html"
    return false
  }

  return true
}

// Logout function
async function logout() {
  await supabase.auth.signOut()
  window.location.href = "login.html"
}

// Initialize auth check on page load
document.addEventListener("DOMContentLoaded", async () => {
  // Check if we're on the login or signup page
  const isAuthPage = window.location.pathname.includes("login.html") || window.location.pathname.includes("signup.html")

  if (!isAuthPage) {
    // Only check auth on non-auth pages
    const isAuthenticated = await checkAuth()

    if (!isAuthenticated) {
      return // Stop execution if not authenticated
    }
  }

  // Initialize the app if we're on the main page
  if (
    window.location.pathname.includes("index.html") ||
    window.location.pathname === "/" ||
    window.location.pathname === ""
  ) {
    if (typeof init === "function") {
      init()
    }
  }
})
