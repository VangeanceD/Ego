import { supabase } from "./supabaseClient" // Import supabase
let player // Declare player

// Save player data to Supabase
async function savePlayerData() {
  if (!player) return

  try {
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      console.error("No authenticated user found")
      return
    }

    const { error } = await supabase.from("player_data").upsert({
      id: user.id,
      player_state: player,
      updated_at: new Date(),
    })

    if (error) {
      console.error("Error saving player data:", error)
    }
  } catch (error) {
    console.error("Error in savePlayerData:", error)
  }
}

// Fetch player data from Supabase
async function fetchPlayerData(userId) {
  try {
    // First, check if player data exists
    const { data: playerData, error: playerError } = await supabase
      .from("player_data")
      .select("player_state")
      .eq("id", userId)
      .single()

    if (playerError && playerError.code !== "PGRST116") {
      console.error("Error fetching player data:", playerError)
      return null
    }

    // Get user profile
    const { data: profile, error: profileError } = await supabase
      .from("profiles")
      .select("username")
      .eq("id", userId)
      .single()

    if (profileError) {
      console.error("Error fetching profile:", profileError)
      return null
    }

    if (playerData && playerData.player_state && Object.keys(playerData.player_state).length > 0) {
      // Player data exists, use it
      return playerData.player_state
    } else {
      // Create new player data with the username from profile
      const newPlayer = createDefaultPlayer(profile.username)

      // Save to Supabase
      const {
        data: { user },
      } = await supabase.auth.getUser()

      const { error } = await supabase.from("player_data").upsert({
        id: user.id,
        player_state: newPlayer,
        updated_at: new Date(),
      })

      if (error) {
        console.error("Error creating player data:", error)
        return null
      }

      return newPlayer
    }
  } catch (error) {
    console.error("Error in fetchPlayerData:", error)
    return null
  }
}

// Create default player data
function createDefaultPlayer(username) {
  return {
    name: username,
    level: 1,
    xp: 0,
    xpToNextLevel: 100,
    rank: "E",
    stats: {
      strength: 1,
      endurance: 1,
      focus: 1,
      discipline: 1,
      agility: 1,
      intelligence: 1,
    },
    quests: [
      {
        id: "1",
        title: "Morning Exercise",
        description: "Complete a 10-minute workout to start your day energized",
        xp: 50,
        timeLimit: 10,
        category: "physical",
        completed: false,
        stats: ["strength", "endurance"],
        punishment: "No workout today! Your muscles are getting weaker.",
      },
      {
        id: "2",
        title: "Meditation Session",
        description: "Practice mindfulness meditation to improve focus",
        xp: 30,
        timeLimit: 5,
        category: "mental",
        completed: false,
        stats: ["focus", "discipline"],
        punishment: "Your mind remains cluttered and unfocused.",
      },
    ],
    rewards: [
      {
        id: "1",
        title: "Cheat Day",
        description: "Enjoy your favorite fast food without guilt",
        cost: 100,
        icon: "pizza",
        custom: false,
      },
      {
        id: "2",
        title: "Gaming Session",
        description: "2 hours of guilt-free gaming",
        cost: 50,
        icon: "gamepad-2",
        custom: false,
      },
    ],
    completedQuests: [],
    claimedRewards: [],
    settings: {
      theme: "blue",
      animations: true,
      notifications: true,
    },
    profilePicture: null,
  }
}
