import { supabase } from "./supabaseClient.js"

async function testConnection() {
  try {
    // Test the connection by getting the current user
    const { data, error } = await supabase.auth.getSession()

    if (error) {
      console.error("Connection error:", error.message)
      return false
    }

    console.log("Successfully connected to Supabase!")
    console.log("Session data:", data)

    // Test database access
    const { data: profiles, error: profilesError } = await supabase.from("profiles").select("*").limit(1)

    if (profilesError) {
      if (profilesError.code === "PGRST116") {
        console.log("No profiles found, but connection is working!")
      } else {
        console.error("Error accessing profiles table:", profilesError.message)
      }
    } else {
      console.log("Successfully accessed profiles table!")
      console.log("Profiles data:", profiles)
    }

    return true
  } catch (err) {
    console.error("Unexpected error:", err.message)
    return false
  }
}

// Run the test
testConnection()
